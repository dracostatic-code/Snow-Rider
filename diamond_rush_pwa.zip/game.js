(()=>{"use strict";
const $=id=>document.getElementById(id),canvas=$("scene"),ctx=canvas.getContext("2d");
const defaults={magnet:0,multiplier:0,shield:0,board:0};
let save=JSON.parse(localStorage.getItem("dr_save")||"null")||{gems:0,best:0,runs:0,upgrades:{...defaults}};
save.upgrades={...defaults,...save.upgrades};
const specs=[
 {id:"magnet",icon:"🧲",name:"Diamond Magnet",desc:"Pull diamonds from further away.",base:35,cap:8,effect:l=>`Pickup range +${l*9}%`},
 {id:"multiplier",icon:"✨",name:"Gem Multiplier",desc:"Earn more diamonds on every run.",base:55,cap:10,effect:l=>`Diamond rewards ×${(1+l*.25).toFixed(2)}`},
 {id:"shield",icon:"🛡️",name:"Crash Shield",desc:"Survive one collision per run.",base:85,cap:5,effect:l=>l?`One save every run · level ${l}`:"No collision protection"},
 {id:"board",icon:"🏂",name:"Pro Sled",desc:"Start each run with a speed bonus.",base:65,cap:7,effect:l=>`Starting boost level ${l}`}
];
function persist(){localStorage.setItem("dr_save",JSON.stringify(save));updateHome()}
function cost(s){return Math.round(s.base*Math.pow(1.72,save.upgrades[s.id]))}
function updateHome(){$("wallet").textContent=save.gems;$("shop-wallet").textContent=save.gems;$("best").textContent=save.best+" m";$("runs").textContent=save.runs;$("level").textContent=1+Object.values(save.upgrades).reduce((a,b)=>a+b,0);renderShop()}
function renderShop(){$("upgrades").innerHTML=specs.map(s=>{let l=save.upgrades[s.id],c=cost(s);return `<article class="upgrade"><div class="uicon">${s.icon}</div><div><h3>${s.name} · Lv ${l}/${s.cap}</h3><p>${s.effect(l)}</p></div><button data-buy="${s.id}" ${l>=s.cap||save.gems<c?"disabled":""}>${l>=s.cap?"MAX":`💎 ${c}`}</button></article>`}).join("");$("upgrades").querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>buy(b.dataset.buy))}
function buy(id){let s=specs.find(x=>x.id===id),l=save.upgrades[id],c=cost(s);if(l>=s.cap||save.gems<c)return;save.gems-=c;save.upgrades[id]++;persist()}
function screen(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active")}
$("play").onclick=start;$("shop-open").onclick=()=>{renderShop();screen("shop")};$("how-open").onclick=()=>screen("how");document.querySelectorAll("[data-back]").forEach(b=>b.onclick=()=>screen("home"));$("to-home").onclick=()=>screen("home");$("again").onclick=start;
let active=false,paused=false,ended=false,frame=0,last=0,dist=0,runGems=0,speed=4,lane=1,playerJump=0,duck=0,objects=[],spawn=0,shieldUsed=false,toastTime=0,swipe=null,shake=0;
const lanes=[.25,.5,.75],clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rand=(a,b)=>a+Math.random()*(b-a);
function resize(){let r=canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);canvas.width=Math.max(1,Math.floor(r.width*d));canvas.height=Math.max(1,Math.floor(r.height*d));ctx.setTransform(d,0,0,d,0,0)}new ResizeObserver(resize).observe(canvas);
function start(){screen("game");resize();active=true;paused=false;ended=false;frame=0;last=0;dist=0;runGems=0;speed=4+save.upgrades.board*.18;lane=1;playerJump=0;duck=0;objects=[];spawn=0;shieldUsed=false;shake=0;$("run-gems").textContent="0";$("distance").textContent="0 m";$("pause").textContent="Ⅱ";$("hint").style.display="block";requestAnimationFrame(loop)}
function add(type,l,y=-.12){objects.push({type,l,y,hit:false,phase:Math.random()*6})}
function wave(){let hazard=Math.random()<.7;if(hazard){let l=Math.floor(rand(0,3)),type=["rock","tree","barrier","gap"][Math.floor(rand(0,4))];add(type,l);if(Math.random()<.28)add("rock",(l+1+Math.floor(rand(0,2)))%3,-.34)}
// generous trails, usually in an open lane
let safe=hazard?((objects[objects.length-1]?.l??1)+1)%3:Math.floor(rand(0,3));
if(Math.random()<.98){let n=4+Math.floor(Math.random()*4),spacing=.105;for(let i=0;i<n;i++)add("gem",safe,-.13-i*spacing)}
}
function project(l,y){let w=canvas.clientWidth,h=canvas.clientHeight,depth=clamp((y+.15)/1.15,0,1.1),roadW=w*(.13+.82*depth),center=w/2+(l-1)*roadW*.31;return {x:center,y:h*(.1+depth*.88),scale:.23+depth*1.5,roadW}}
function drawMountain(w,h){let g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,"#8bd4ec");g.addColorStop(.5,"#d7f5fb");g.addColorStop(1,"#f8fdff");ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
ctx.fillStyle="#a4cbd9";ctx.beginPath();ctx.moveTo(0,h*.48);ctx.lineTo(w*.16,h*.12);ctx.lineTo(w*.29,h*.43);ctx.lineTo(w*.48,h*.08);ctx.lineTo(w*.7,h*.45);ctx.lineTo(w*.87,h*.16);ctx.lineTo(w,h*.48);ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.fill();
ctx.fillStyle="#f5fdff";ctx.beginPath();ctx.moveTo(0,h*.52);ctx.lineTo(w*.16,h*.12);ctx.lineTo(w*.29,h*.43);ctx.lineTo(w*.48,h*.08);ctx.lineTo(w*.7,h*.45);ctx.lineTo(w*.87,h*.16);ctx.lineTo(w,h*.48);ctx.lineTo(w,h*.61);ctx.lineTo(0,h*.62);ctx.fill();
let horizon=h*.27, bottom=h*1.12;ctx.fillStyle="#e9f8fc";ctx.beginPath();ctx.moveTo(w*.5-w*.09,horizon);ctx.lineTo(w*.5+w*.09,horizon);ctx.lineTo(w*1.12,bottom);ctx.lineTo(-w*.12,bottom);ctx.fill();
ctx.strokeStyle="#b6dce9";ctx.lineWidth=2;for(let i=-1;i<=1;i++){ctx.beginPath();ctx.moveTo(w*.5+i*w*.045,horizon);ctx.lineTo(w*.5+i*w*.46,bottom);ctx.stroke()}
ctx.strokeStyle="#fff";ctx.lineWidth=3;for(let i=0;i<12;i++){let y=horizon+((i*47+frame*speed*2)%(h*.9));let p=(y-horizon)/(bottom-horizon);let x=w*.5+Math.sin(i*4)*p*w*.43;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+rand(-5,5),y+5+p*10);ctx.stroke()}
}
function poly(points,fill,stroke){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke()}}
function drawGem(p){let s=11*p.scale;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(Math.sin(frame*.07)*.2);poly([[0,-s],[s*.75,-s*.25],[s*.5,s],[ -s*.5,s],[-s*.75,-s*.25]],"#14b9e5","#e6fbff");poly([[0,-s*.7],[s*.35,-s*.2],[0,s*.55],[-s*.35,-s*.2]],"#baf4ff");ctx.restore()}
function drawHazard(o,p){let s=p.scale;ctx.save();ctx.translate(p.x,p.y);if(o.type==="rock"){ctx.shadowColor="#6a8995";ctx.shadowBlur=7*s;poly([[-20*s,8*s],[-17*s,-10*s],[-5*s,-19*s],[14*s,-14*s],[23*s,7*s]],"#718e9b","#e9faff")}else if(o.type==="tree"){ctx.fillStyle="#76583d";ctx.fillRect(-4*s,-12*s,8*s,27*s);poly([[0,-40*s],[-23*s,1*s],[23*s,1*s]],"#267954","#e1f7ec");poly([[0,-25*s],[-19*s,12*s],[19*s,12*s]],"#318b60")}else if(o.type==="barrier"){ctx.fillStyle="#b94e45";ctx.fillRect(-25*s,-25*s,50*s,9*s);ctx.fillRect(-22*s,-18*s,7*s,31*s);ctx.fillRect(15*s,-18*s,7*s,31*s);ctx.fillStyle="#fff";ctx.fillRect(-24*s,-24*s,12*s,5*s);ctx.fillRect(12*s,-24*s,12*s,5*s)}else{ctx.fillStyle="#5d9eb5";ctx.fillRect(-29*s,-3*s,58*s,9*s);ctx.fillStyle="#fff";ctx.fillRect(-26*s,-6*s,52*s,4*s)}ctx.restore()}
function drawRider(w,h){let p=project(lane,.78),y=p.y-(playerJump?Math.sin(playerJump/25*Math.PI)*h*.19:0),s=Math.min(w,h)*.0015;ctx.save();ctx.translate(p.x,y);ctx.scale(s,s);ctx.fillStyle="#183b50";ctx.beginPath();ctx.ellipse(0,29,29,8,0,0,7);ctx.fill();ctx.fillStyle="#e99e30";ctx.beginPath();ctx.moveTo(-32,20);ctx.lineTo(32,20);ctx.lineTo(22,28);ctx.lineTo(-23,28);ctx.fill();if(duck>0){ctx.rotate(-.45);ctx.fillStyle="#174d70";ctx.fillRect(-14,-9,30,16);ctx.fillStyle="#dca17b";ctx.beginPath();ctx.arc(12,-11,9,0,7);ctx.fill()}else{ctx.fillStyle="#174d70";ctx.beginPath();ctx.moveTo(-12,9);ctx.lineTo(-9,-20);ctx.lineTo(12,-20);ctx.lineTo(17,9);ctx.fill();ctx.fillStyle="#d9a07a";ctx.beginPath();ctx.arc(2,-29,11,0,7);ctx.fill();ctx.fillStyle="#263c4c";ctx.beginPath();ctx.arc(2,-32,12,Math.PI,Math.PI*2);ctx.fill();ctx.fillStyle="#e4faff";ctx.fillRect(-9,-32,21,5)}ctx.restore()}
function toast(t){$("toast").textContent=t;toastTime=75}
function collect(o){let mult=1+save.upgrades.multiplier*.25;let amount=Math.max(1,Math.round(mult));runGems+=amount;o.hit=true;$("run-gems").textContent=runGems;toast("+"+amount+" 💎");}
function collision(o){if(o.hit)return;let protectedByJump=playerJump>7&&(o.type==="rock"||o.type==="tree"||o.type==="gap"),protectedByDuck=duck>6&&o.type==="barrier";if(protectedByJump||protectedByDuck){o.hit=true;return}if(save.upgrades.shield>0&&!shieldUsed){shieldUsed=true;o.hit=true;shake=12;toast("🛡️ SHIELD SAVED YOU!");return}finish()}
function loop(t){if(!active||paused)return;let dt=Math.min((t-(last||t))/16.67,2);last=t;frame+=dt;let w=canvas.clientWidth,h=canvas.clientHeight;ctx.save();if(shake>0){ctx.translate(rand(-shake,shake),rand(-shake,shake));shake=Math.max(0,shake-dt)}
drawMountain(w,h);spawn+=dt;if(spawn>Math.max(25,55-speed*2.3)){spawn=0;wave()}
dist+=speed*.12*dt;speed=Math.min(10,speed+.0014*dt);objects.forEach(o=>o.y+=speed*.0036*dt);
objects.sort((a,b)=>a.y-b.y);for(let o of objects){let p=project(o.l,o.y);if(o.type==="gem"){drawGem(p);let magnet=save.upgrades.magnet*.012;if(!o.hit&&o.l===lane&&Math.abs(o.y-.78)<.08+magnet){collect(o)}}else{drawHazard(o,p);if(!o.hit&&o.l===lane&&Math.abs(o.y-.78)<.055)collision(o);if(!active)break}}
objects=objects.filter(o=>o.y<1.18&&!o.hit);drawRider(w,h);ctx.restore();playerJump=Math.max(0,playerJump-dt);duck=Math.max(0,duck-dt);$("distance").textContent=Math.floor(dist)+" m";if(toastTime-->0&&toastTime===0)$("toast").textContent="";requestAnimationFrame(loop)}
function finish(){if(!active)return;active=false;ended=true;let reward=Math.round(runGems*(1+save.upgrades.multiplier*.25));save.gems+=reward;save.best=Math.max(save.best,Math.floor(dist));save.runs++;persist();$("earned").textContent=reward;$("final-distance").textContent=Math.floor(dist)+" m";$("final-best").textContent=save.best+" m";$("pause-layer").classList.remove("show");screen("over")}
function move(d){if(active&&!paused)lane=clamp(lane+d,0,2)}
function act(a){if(!active||paused)return;if(a==="left")move(-1);if(a==="right")move(1);if(a==="jump"&&playerJump<=0&&duck<=0)playerJump=25;if(a==="duck"&&duck<=0&&playerJump<=0)duck=28}
document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>act(b.dataset.action)));
$("pause").onclick=()=>{if(!active)return;paused=true;$("pause-layer").classList.add("show")};$("resume").onclick=()=>{paused=false;$("pause-layer").classList.remove("show");last=0;requestAnimationFrame(loop)};$("quit").onclick=()=>finish();
canvas.addEventListener("pointerdown",e=>{swipe={x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId)});canvas.addEventListener("pointerup",e=>{if(!swipe)return;let dx=e.clientX-swipe.x,dy=e.clientY-swipe.y;if(Math.max(Math.abs(dx),Math.abs(dy))>22){if(Math.abs(dx)>Math.abs(dy))move(dx>0?1:-1);else act(dy<0?"jump":"duck")}swipe=null});
document.addEventListener("keydown",e=>{let m={ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right",ArrowUp:"jump"," ":"jump",ArrowDown:"duck",s:"duck"};if(m[e.key]){e.preventDefault();act(m[e.key])}});
updateHome();
})();